# Tutorial To Get Redis DB Url and Password

Process For Creating DB :-   
i.) Go To redislabs.com and click "Try Free" in Top Right Corner.   
ii.) Fill All The Required Details Like email, first and last name, password, etc.   
iii.) Tick Below "I agree the corresponding...Privacy Policy." and Click "Get Started".   
iv) Now Check Your Email, and click the "Activate Now" sent by redislabs via email.   
v) Now Login and Chose Free Plan in "Fixed Size" Area and Write any name in "Subscription Area".   
vi) On the Next Page Write Database Name and click Activate.   
   
 Congo! Your DB has been created 🥳   
   
Process For Getting DB Credentials:-   
i.) Wait 5 mins after DB creation.   
ii.) Then There Would Be 2 Things Named "Endpoint" and "Access Control & Security".   
iii.) Copy Both Of Them and Paste Endpoint url in `REDIS_URI` and "Access ...Secrutity" in `REDIS_PASSWORD`.   
